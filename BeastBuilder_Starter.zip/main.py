# BeastBuilder main AI logic
def start():
    print('Welcome to BeastBuilder!')
    # Initialization and project walkthrough logic goes here
if __name__ == '__main__':
    start()
